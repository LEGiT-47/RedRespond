-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: redrespond
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_donationrequest`
--

DROP TABLE IF EXISTS `main_donationrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `main_donationrequest` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `blood_group` varchar(5) NOT NULL,
  `requested_amount` decimal(5,2) NOT NULL,
  `request_datetime` datetime(6) NOT NULL,
  `status` varchar(20) NOT NULL,
  `additional_info` longtext,
  `blood_bank_id` bigint NOT NULL,
  `sent_requests` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `main_donationrequest_blood_bank_id_f72a456a_fk_main_bloodbank_id` (`blood_bank_id`),
  CONSTRAINT `main_donationrequest_blood_bank_id_f72a456a_fk_main_bloodbank_id` FOREIGN KEY (`blood_bank_id`) REFERENCES `main_bloodbank` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_donationrequest`
--

LOCK TABLES `main_donationrequest` WRITE;
/*!40000 ALTER TABLE `main_donationrequest` DISABLE KEYS */;
INSERT INTO `main_donationrequest` VALUES (1,'O+',30.00,'2025-03-24 08:42:00.000000','pending','eff',1,0),(2,'O+',30.00,'2025-03-26 09:21:00.000000','pending','ss',1,1),(3,'O+',40.00,'2025-03-24 13:03:00.000000','pending','scc',1,1),(4,'O+',40.00,'2025-03-24 13:03:00.000000','pending','scc',1,1),(5,'O+',40.00,'2025-03-24 13:03:00.000000','pending','scc',1,1),(6,'O+',30.00,'2025-03-24 13:09:00.000000','pending',',lyhl',1,1),(7,'O+',20.00,'2025-03-25 13:13:00.000000','pending','ohoh',1,1),(8,'O+',20.00,'2025-03-25 13:13:00.000000','pending','ohoh',1,1),(9,'O+',20.00,'2025-03-25 13:13:00.000000','pending','ohoh',1,1),(10,'O+',60.00,'2025-03-27 15:04:00.000000','pending','nnj',1,1),(11,'O+',60.00,'2025-03-27 15:04:00.000000','pending','nnj',1,1),(12,'O+',60.00,'2025-03-27 15:04:00.000000','pending','nnj',1,1),(13,'O+',60.00,'2025-03-27 15:04:00.000000','pending','nnj',1,1),(14,'O+',100.00,'2025-03-25 15:31:00.000000','pending','knkin',1,1),(15,'O+',10.00,'2025-03-25 15:33:00.000000','pending','wow',1,1),(16,'O+',30.00,'2025-03-20 15:34:00.000000','pending','',1,1),(17,'O+',30.00,'2025-03-20 15:34:00.000000','fulfilled','',1,1),(18,'O+',100.00,'2025-03-25 19:31:00.000000','pending','mmm',1,1),(19,'O+',70.00,'2025-03-25 19:36:00.000000','pending','hiiiiiiiiiiiiiiiiiiiiiiiiii',1,1),(20,'O+',70.00,'2025-03-25 19:36:00.000000','pending','kjcbvsssssss',1,1),(21,'O+',70.00,'2025-03-25 19:36:00.000000','fulfilled','adsooooooooooads',1,1),(22,'O+',70.00,'2025-03-25 19:36:00.000000','pending','pppppppppppppppppppp',1,1),(23,'O+',70.00,'2025-03-25 19:36:00.000000','pending','lullllllllllll',1,1),(24,'O+',40.00,'2025-03-26 10:18:00.000000','pending','objobc',1,1),(25,'O+',40.00,'2025-03-26 10:18:00.000000','pending','objobc',1,1),(26,'O+',40.00,'2025-03-26 18:07:00.000000','fulfilled','helppp',1,1),(27,'O+',40.00,'2025-03-26 18:07:00.000000','fulfilled','helppp',1,1),(28,'O+',70.00,'2025-03-28 18:42:00.000000','pending','csc',1,1);
/*!40000 ALTER TABLE `main_donationrequest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-28 15:29:39
