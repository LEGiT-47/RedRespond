-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: redrespond
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_donationrequest`
--

DROP TABLE IF EXISTS `main_donationrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `main_donationrequest` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `blood_group` varchar(5) NOT NULL,
  `requested_amount` decimal(5,2) NOT NULL,
  `request_datetime` datetime(6) NOT NULL,
  `status` varchar(20) NOT NULL,
  `additional_info` longtext,
  `blood_bank_id` bigint NOT NULL,
  `sent_requests` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `main_donationrequest_blood_bank_id_f72a456a_fk_main_bloodbank_id` (`blood_bank_id`),
  CONSTRAINT `main_donationrequest_blood_bank_id_f72a456a_fk_main_bloodbank_id` FOREIGN KEY (`blood_bank_id`) REFERENCES `main_bloodbank` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_donationrequest`
--

LOCK TABLES `main_donationrequest` WRITE;
/*!40000 ALTER TABLE `main_donationrequest` DISABLE KEYS */;
INSERT INTO `main_donationrequest` VALUES (27,'O+',40.00,'2025-03-26 18:07:00.000000','fulfilled','helppp',1,1),(28,'O+',70.00,'2025-03-28 18:42:00.000000','pending','csc',1,1),(29,'O+',90.00,'2025-04-21 22:13:00.000000','fulfilled','urgent  for a baby',1,1),(30,'O+',130.00,'2025-04-22 08:54:00.000000','pending','urgent',1,2),(31,'O+',130.00,'2025-04-22 08:54:00.000000','fulfilled','urgent',1,2),(32,'O+',150.00,'2025-04-24 16:35:00.000000','pending','urgent',1,2),(33,'O+',110.00,'2025-04-24 17:42:00.000000','fulfilled','help',1,1),(34,'O+',110.00,'2025-04-24 17:42:00.000000','fulfilled','help',1,2),(35,'O+',80.00,'2025-04-24 06:35:00.000000','fulfilled','urgent',1,2),(36,'O+',80.00,'2025-04-24 06:35:00.000000','pending','urgent',1,2),(37,'O+',80.00,'2025-04-24 06:35:00.000000','pending','urgent',1,2),(38,'O+',80.00,'2025-04-24 06:35:00.000000','pending','urgent',1,2);
/*!40000 ALTER TABLE `main_donationrequest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-24  7:13:54
