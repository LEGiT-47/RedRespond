-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: redrespond
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-01-30 15:38:28.970935'),(2,'contenttypes','0002_remove_content_type_name','2025-01-30 15:38:29.043348'),(3,'auth','0001_initial','2025-01-30 15:38:29.376692'),(4,'auth','0002_alter_permission_name_max_length','2025-01-30 15:38:29.439595'),(5,'auth','0003_alter_user_email_max_length','2025-01-30 15:38:29.446414'),(6,'auth','0004_alter_user_username_opts','2025-01-30 15:38:29.452842'),(7,'auth','0005_alter_user_last_login_null','2025-01-30 15:38:29.459842'),(8,'auth','0006_require_contenttypes_0002','2025-01-30 15:38:29.463763'),(9,'auth','0007_alter_validators_add_error_messages','2025-01-30 15:38:29.473769'),(10,'auth','0008_alter_user_username_max_length','2025-01-30 15:38:29.497912'),(11,'auth','0009_alter_user_last_name_max_length','2025-01-30 15:38:29.504913'),(12,'auth','0010_alter_group_name_max_length','2025-01-30 15:38:29.522130'),(13,'auth','0011_update_proxy_permissions','2025-01-30 15:38:29.530302'),(14,'auth','0012_alter_user_first_name_max_length','2025-01-30 15:38:29.537386'),(15,'main','0001_initial','2025-01-30 15:38:29.885162'),(16,'admin','0001_initial','2025-01-30 15:38:30.027529'),(17,'admin','0002_logentry_remove_auto_add','2025-01-30 15:38:30.039061'),(18,'admin','0003_logentry_add_action_flag_choices','2025-01-30 15:38:30.049552'),(19,'main','0002_customuser_address_customuser_blood_group_and_more','2025-01-30 15:38:30.312337'),(20,'main','0003_remove_customuser_blood_group_and_more','2025-01-30 15:38:30.575030'),(21,'sessions','0001_initial','2025-01-30 15:38:30.614962'),(22,'main','0004_donation','2025-02-06 18:46:41.409515'),(23,'main','0005_donation_bloodgroup_donation_not_accepted_reason_and_more','2025-03-08 04:28:23.408206'),(24,'main','0006_remove_donation_bloodgroup','2025-03-08 04:32:11.301375'),(25,'main','0007_remove_donation_confirmed','2025-03-08 04:46:36.863939'),(26,'main','0008_donation_additional_info','2025-03-08 16:13:34.060903'),(27,'main','0009_alter_donation_donor','2025-03-08 19:57:06.350608'),(28,'main','0010_alter_donation_donor','2025-03-08 19:57:06.378266'),(29,'main','0011_customuser_telegram_chat_id','2025-03-20 02:43:59.542933'),(30,'main','0012_donationrequest','2025-03-23 08:34:35.726761'),(31,'main','0013_donationrequest_sent_requests_fulfilledrequests','2025-03-23 09:09:05.406042'),(32,'main','0014_alter_fulfilledrequests_donation_request','2025-03-23 09:11:52.669396'),(33,'main','0015_alter_fulfilledrequests_users','2025-03-23 09:14:37.089725'),(34,'main','0016_rename_donation_request_fulfilledrequests_donation_req_id','2025-03-23 09:21:34.318705'),(35,'main','0017_remove_fulfilledrequests_users_and_more','2025-03-23 13:01:20.400162'),(36,'main','0018_fulfilledrequests_fulfilled_by_and_more','2025-03-23 14:57:24.393375'),(37,'main','0019_remove_fulfilledrequests_fulfilled_by_and_more','2025-03-23 14:57:24.461829'),(38,'main','0020_fulfilledrequests_fulfilled_by_and_more','2025-03-23 14:57:24.614026'),(39,'main','0021_customuser_loc_latitude_customuser_loc_longitude','2025-03-27 17:49:23.826718'),(40,'main','0022_alter_customuser_email','2025-03-28 10:32:02.693790'),(41,'main','0023_bloodbank_max_capacity_per_group_stock','2025-03-29 14:00:05.066984'),(42,'main','0024_delete_stock','2025-03-29 14:10:19.481699'),(43,'main','0025_bloodbank_a0_bloodbank_a1_bloodbank_ab0_and_more','2025-03-30 02:47:48.185396'),(44,'main','0026_bloodbank_website','2025-03-31 12:41:27.533474'),(45,'main','0027_alter_bloodbank_website','2025-04-06 17:34:58.363386'),(46,'django_celery_beat','0001_initial','2025-04-17 11:56:00.199081'),(47,'django_celery_beat','0002_auto_20161118_0346','2025-04-17 11:56:00.265874'),(48,'django_celery_beat','0003_auto_20161209_0049','2025-04-17 11:56:00.286602'),(49,'django_celery_beat','0004_auto_20170221_0000','2025-04-17 11:56:00.290504'),(50,'django_celery_beat','0005_add_solarschedule_events_choices','2025-04-17 11:56:00.294513'),(51,'django_celery_beat','0006_auto_20180322_0932','2025-04-17 11:56:00.358186'),(52,'django_celery_beat','0007_auto_20180521_0826','2025-04-17 11:56:00.399237'),(53,'django_celery_beat','0008_auto_20180914_1922','2025-04-17 11:56:00.425601'),(54,'django_celery_beat','0006_auto_20180210_1226','2025-04-17 11:56:00.441631'),(55,'django_celery_beat','0006_periodictask_priority','2025-04-17 11:56:00.525077'),(56,'django_celery_beat','0009_periodictask_headers','2025-04-17 11:56:00.581962'),(57,'django_celery_beat','0010_auto_20190429_0326','2025-04-17 11:56:00.723927'),(58,'django_celery_beat','0011_auto_20190508_0153','2025-04-17 11:56:00.791940'),(59,'django_celery_beat','0012_periodictask_expire_seconds','2025-04-17 11:56:00.844228'),(60,'django_celery_beat','0013_auto_20200609_0727','2025-04-17 11:56:00.855040'),(61,'django_celery_beat','0014_remove_clockedschedule_enabled','2025-04-17 11:56:00.866229'),(62,'django_celery_beat','0015_edit_solarschedule_events_choices','2025-04-17 11:56:00.870525'),(63,'django_celery_beat','0016_alter_crontabschedule_timezone','2025-04-17 11:56:00.878647'),(64,'django_celery_beat','0017_alter_crontabschedule_month_of_year','2025-04-17 11:56:00.885892'),(65,'django_celery_beat','0018_improve_crontab_helptext','2025-04-17 11:56:00.893057'),(66,'django_celery_beat','0019_alter_periodictasks_options','2025-04-17 11:56:00.895806');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-24  4:17:45
