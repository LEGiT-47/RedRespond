-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: redrespond
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_customuser`
--

DROP TABLE IF EXISTS `main_customuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `main_customuser` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `address` longtext,
  `city` varchar(100) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `telegram_chat_id` varchar(50) DEFAULT NULL,
  `loc_latitude` decimal(10,7) NOT NULL,
  `loc_longitude` decimal(10,7) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_customuser`
--

LOCK TABLES `main_customuser` WRITE;
/*!40000 ALTER TABLE `main_customuser` DISABLE KEYS */;
INSERT INTO `main_customuser` VALUES (1,'pbkdf2_sha256$870000$OwgFO5q076TgVJdHDy43D2$gDCyTKEU/VZZw1ZvOcHQ6Jq7AKWLFOv5m0RHd5J1T+0=','2025-04-23 18:12:56.332873',1,'vir','Viraj','Prabhu','virajprabhu47@gmail.com',1,1,'2025-01-30 17:54:42.000000','normal','MUMBAI','MUMBAI','9004041406','400063','MAHARASHTRA','1612995585',19.1655490,72.8523417),(2,'pbkdf2_sha256$870000$iNu0MbixlQKIDQFFbUIIMf$lL3rM2SLvX0MC9eBosY1lvXrkkRzv2QRCsxEnsQeUQY=','2025-04-23 18:01:56.548491',1,'sid','Falguni','-','siddhant33@gmail.com',1,1,'2025-01-30 19:05:58.000000','blood_bank','Borivali  West , Mumbai , Maharashtra','MUMBAI','1234567890','400063','MAHARASHTRA',NULL,19.2415000,72.8548000),(5,'falguni@1234','2025-03-20 03:08:27.000000',1,'Falguni','Falguni','-','virajprabhu6@gmail.com',0,1,'2025-03-20 03:08:11.000000','normal','MUMBAI','MUMBAI','8655408040','400063','MAHARASHTRA','6333557271',19.1674517,72.8513831),(8,'pbkdf2_sha256$870000$QjBafhOamcIjBnpapqz3n9$GB9L3L/868vEgwdPhT5MdNxfSCIkp3Rvnm0ISZNfm7E=','2025-04-22 23:55:47.609463',0,'vishwa_kripa','','','vk@gmail.com',0,1,'2025-03-27 18:18:05.000000','blood_bank','Aarey Road , Goregaon East','MUMBAI','1234567890','400063','MAHARASHTRA',NULL,19.1669000,72.8518700),(12,'pbkdf2_sha256$870000$WNKXAHYArmYgQPlvCsL51G$34fW5Bk6FwFgMWjaX8TxkBT7vEQV9PZY4uP1aLPYH/w=','2025-04-06 17:41:38.684230',0,'Falguni2','','','virajprabhu6.vp@gmail.com',0,1,'2025-04-06 17:41:38.346084','normal','Aarey Road , Goregaon East','MUMBAI','8779953387','400063','MAHARASHTRA','7920211911',19.1674517,72.8513831),(20,'pbkdf2_sha256$870000$rHIiwyWGurw6DYM5wcJNVy$WhhCRGPZA3zAZsxkveUf+7YWuununaTb94PoAP1LDU0=','2025-04-23 17:56:49.271308',0,'Ghrani','','','ghranipoojari1912@gmail.com',0,1,'2025-04-22 05:42:57.473175','normal','MUMBAI','MUMBAI','8169653130','400063','MAHARASHTRA','5279682618',19.2436371,72.8560887);
/*!40000 ALTER TABLE `main_customuser` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-24  2:59:19
